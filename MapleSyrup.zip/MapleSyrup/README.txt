MapleSyrup - the MapleStory companion
=====================================

Installed with the installer
  The installer asks for your API keys - OpenAI (talking, seeing your
  screen), ElevenLabs (the voices on the phone), xAI (optional: Grok) - and
  keeps them in %APPDATA%\MapleSyrup; it installs Claude Code when this PC
  doesn't have it, and adds MapleSyrup to the Claude desktop app when that
  is here. Then "MapleSyrup" on the desktop (or in the Start menu) starts it
  all: MapleSyrup with the phone over the internet (scan its QR code from
  any network, mobile data too) and Claude in a window of its own, talking
  with you through the phone in the voice you pick (Settings -> Voice). The
  first time, Claude Code asks you to log in to your Claude account (a
  browser opens); to "development channel" choose "I am using this for
  local development", and to auto mode say yes.
  Without Claude: "MapleSyrup without Claude" in the Start menu. The phone on
  the same Wi-Fi, without the internet link: "MapleSyrup (phone on the same
  Wi-Fi)".

Start
  1. Start MapleSyrup: from the Start menu or the desktop icon if you used the
     installer, or double-click MapleSyrup.exe from the zip.
     The first time, it asks for an OpenAI API key (platform.openai.com/api-keys)
     so it can talk like ChatGPT in a natural voice and see your screen. Paste
     it and press Enter (it is kept on this PC only, in %APPDATA%\MapleSyrup), or
     press Enter to go without (simple answers, Windows voice). A key can also
     be put in a file called openai-key.txt next to MapleSyrup.exe.
  2. Start MapleStory (windowed or borderless windowed). MapleSyrup's dog (the
     chow chow from the logo) and a small HP/MP/EXP panel appear at the top
     right of the game.
  3. On your phone (same Wi-Fi as the PC), scan the QR code in MapleSyrup's window.
     Until your phone trusts this PC, it warns that the page is "not
     private": the certificate was made on your PC, not by a public authority.
       iPhone:  Show Details -> visit this website -> Visit Website
       Android: Advanced -> Proceed
     The page then offers "Trust this PC": once, the phone trusts MapleSyrup's
     own certificate authority on your PC, and the warning is gone for good
     (iPhone: allow the profile, Settings -> Profile Downloaded -> Install,
     then Settings -> General -> About -> Certificate Trust Settings -> turn
     on "MapleSyrup ..."). That authority can sign only for addresses on your
     own network (and local names), so trusting it trusts nothing else.
  4. Tap "Start listening", allow the microphone, and just talk to it:
     "hey, how am I doing?", "how long until I level?", "mark that!".
     It says hello once per visit (a page reloaded within half an hour is
     the same visit): the live call's hello when a call is coming, else its
     own (on the phone, heard once you have tapped). A player it does not
     know yet hears what it does ("I yell when your HP drops. Ask me
     stuff."). What waited for your first tap is played only while it is
     still news.

  If Windows asks whether MapleSyrup may use the network, allow private networks.

How it talks
  Like a gamer friend on voice chat, not an assistant: one short sentence,
  the point first, no "let me check", and it tells you what to do. Pick how
  it talks to you on the phone (Settings -> "How it talks to you"):
    Friendly  warm and fun, no swearing
    Blunt     the usual: bossy, cocky, teases you, swears a little
    Savage    swears and roasts you personally (you asked for it); it still
              won't go after who you are (religion, origin, gender and so on)
  Your own numbers are answered at once, without asking a model: "how much HP
  do I have", "what level am I", "how long to level" (English or Hebrew).
  When it isn't sure of a game fact, it says its best guess right away and
  checks it in the background; it speaks again only if it was wrong.
  Grok: with an xAI key, Grok answers the conversation (quick, and freer with
  its words). Put the key in a file named xai-key.txt next to MapleSyrup.exe;
  it moves itself into %APPDATA%\MapleSyrup. OpenAI still makes the voice,
  the look-ups and the live call, and answers whenever Grok can't.

  Its voice: with an ElevenLabs key, pick the voice it speaks in on the phone
  (Settings -> Voice: the voices on your ElevenLabs account, or OpenAI's).
  Put the key in a file named elevenlabs-key.txt next to MapleSyrup.exe; it
  moves itself into %APPDATA%\MapleSyrup. The voice you pick says everything
  except a live call, which speaks in its own voice (the call stays on when
  you pick a voice; turn it off under "Live call on the phone" if you want
  the picked voice for replies too).
  Hebrew is spoken by ElevenLabs' Eleven v4; when your account can't use it,
  or ElevenLabs is down or out of credit, OpenAI's voice says the line.

  With an OpenAI key, talking to it is a live call, like ChatGPT's voice mode:
  its voice comes from the phone (or earbuds on the phone), and the phone
  listens while it talks. Speak any language, switch or mix languages
  mid-sentence (Hebrew and English, say) and it follows you, with no setting.
  Talk over it and it stops and goes with what you said. It sees your screen
  while MapleStory is the window in front, and says its own lines (low HP,
  a level-up) on the call too, in the language you're speaking: handed to
  the call at most every 20 seconds, with the number only for HP and MP; a
  death or a level-up goes at once and is said even when it comes late. A
  glance at another app costs nothing. If the phone sleeps and the call
  drops, MapleSyrup notices within seconds and its lines go back to its own
  voice, the one it was about to hand over included. While it talks,
  MapleStory's sound is turned down.
  Prefer its voice on the PC speakers? Choose "PC" under "Replies spoken on"
  on the phone: then it works as below.

  Like talking to a friend: it answers everything you say, knowing what is on
  your screen (HP, MP, EXP, level, your EXP per hour). If you talk to your
  stream's chat instead, it stays quiet.
  It answers as soon as you stop talking, and its voice starts while the
  rest of the answer is still being made; a plain "hey" it answers at once.
  It doesn't read your level, map or bars back to you unless you ask, and
  before the game is open it just talks. It answers from what it knows
  rather than stopping to look things up, even when it isn't completely
  sure ("I think..."): when it gets something wrong, just correct it, and
  it remembers (see "It learns as you play"). Talk over it and it stops and
  listens ("wait", or just ask something else); a warning, or news such as
  a death, still plays out on the PC. Pause mid-sentence and go on, and it
  waits for the rest instead of answering half of it. The phone keeps
  listening while it talks on the PC and tells your voice from its own.
  While it speaks, MapleStory's sound is turned down for a moment.
  The OpenAI account needs credit (platform.openai.com/settings/organization/billing);
  without it MapleSyrup says so and goes on with simple answers and the
  Windows voice. It also speaks up by itself when HP or MP runs low, when you
  take a beating, when you die and when you level up (a level-up is the level
  at the bottom left going up by one — nothing else counts): a warning is
  shouted, a death or a level-up told.
  A warning is said once per fight. Pot after it and the beating is not
  shouted again in that fight, and the low bar not until the fight is over
  or the bar goes lower; a low bar nothing answers is said again, then
  asked about ("Are you going to pot or not?"). After four warnings that
  nothing answers (not a word, no potion for HP or MP, no EXP) it stops
  ("Okay. No more pot talk from me." — "you're away" words only if you have
  been silent ten minutes) and holds the rest, and the coach's looks, for
  ten minutes, until you speak, or until you pot ("There it is."). Pot
  within three seconds of the shout three fights running and it stops
  shouting "back off": it watches instead, and shouts when HP goes deeper
  than you usually let it, when the potion is late, or under half the
  warning level — never quiet near the bottom of the bar; after a late
  potion, no potion or a death, it shouts again until you have handled
  three more. A reading has to hold: one odd frame is neither a
  potion nor a fall, and a bar it can only guess at is not warned from. A
  bar that reads low for minutes while your EXP keeps coming is a bar it is
  reading wrong: it says so once ("I'm reading your HP wrong") and holds
  that bar's warnings until it reads above the warning level again. A
  warning you answered with a potion before it was heard (its voice still
  being made, waiting for you to finish talking, or for the live call's
  turn) is dropped, not said: no "drink, you're at 12" after you potted
  back to 100. On the phone a line is as old as the PC made it, not as its
  arrival: one that waited out a stalled link is shown, not said.
  "Don't talk to me this way" makes it friendly.
  On the phone you can choose where replies are spoken (PC, phone, both, off)
  and switch to "only after 'syrup'" for streaming.

The dog
  At the top of the phone page MapleSyrup's dog lives in a box of its own. It
  hops about, runs, jumps, spins, rolls over, sniffs around, scratches, plays
  with its ball and naps in its bed, as it feels like it. It looks at you
  while you talk, tilts its head while it thinks, and talks: its mouth opens
  as far as the voice is loud. It barks at danger, jumps for joy when you
  level up, and plays dead when your character dies. Tap the box and it comes
  running; tap the dog to pet it. On the PC it sits beside the panel over
  the game and talks there too.

It sees your screen, and learns it
  With each thing you say, the model gets a picture of the game, so you can
  ask about anything on screen. When MapleStory first shows up, MapleSyrup
  asks a vision model where your level, HP, MP and EXP bars and minimap are
  (any resolution or UI layout), then measures the bars itself on every
  frame and checks them against the game's numbers every couple of minutes.
  You can see what it found in hud-found.png in the session folder.

  Teach it by talking:
    "see that? that's an Orange Mushroom - tell me when one shows up"
    "that's the boss's HP bar, warn me when it's under 20%"
    "I'm level 61" / "that's not my HP"      (corrections)
    "remember that my boss menu key is F10"  (kept for good)
  Each thing it learns keeps a picture (and gets more as it sees it in other
  poses). The phone lists what it has learned, with a Forget button.
  It all lives in %APPDATA%\MapleSyrup\learned (about-me.txt next to it).
  It can also look MapleStory questions up on the web, when you ask it to
  ("look it up") or when it has no idea (start it with --no-web to stop that).

It learns as you play
  The more you play together, the better it gets. Every few minutes, and when
  it starts (for the sessions before), it looks back on what was said and
  keeps a notebook: you and your characters, what you're working towards,
  how you like it to talk, the names you use (so it hears them right), and
  what you did lately, so next time it picks up from there.
  Your corrections teach it: "no, Easy Zakum is level 50" is kept for good,
  and it trusts that over what it thought. What it looked up is kept too, so
  the same question is answered at once next time.
  It adapts to how you talk: it answers quickly after you stop talking, and
  waits a little longer if you often pause mid-sentence and go on; on a live
  call it waits longer if it keeps jumping in before you finish; if you often
  talk over long answers, it keeps them shorter.
  Warnings too: "warn me at 40%", "no more MP warnings", "warn me like
  before". If you die with no warning in that fight while your HP went down,
  it warns you sooner from then on (up to half the bar), and says so.
  The phone shows what it knows about you ("What I know about you"), with a
  Forget button on each thing. It all stays on your PC, in
  %APPDATA%\MapleSyrup\memory.json and knowledge.json: delete them to make it
  forget everything.

Languages
  The phone page speaks English, Hebrew, Spanish, Portuguese, French, German,
  Korean, Japanese, Chinese (simplified and traditional), Thai, Vietnamese,
  Indonesian and Russian. It follows the phone's language; pick another on the
  main screen, under "Start listening". That is also the language the phone
  listens in; when a live call hears you speak Hebrew (two sentences, or a
  long one), the phone listens in Hebrew off the call too, shows "Hearing:
  עברית ×" beside the picker (tap × to undo), and goes back after two
  English ones. Or just say "talk to me in Hebrew" (or "in English", "in
  Spanish"...): it switches at once, the phone included; in Hebrew its own
  lines (warnings, deaths, level-ups) are its own Hebrew, not a
  translation.
  MapleSyrup answers in the language you speak to it and says its own lines
  (warnings, level ups) in yours too. The installer speaks yours when Inno
  Setup has it.

Recording the session
  Tap "Record the session" on the phone (or just say "start recording"; tap
  or say "stop recording" to stop). MapleSyrup records a video of the whole
  screen with every sound: the game, MapleSyrup's voice (on the PC or on a
  live call on the phone), and you from the phone's microphone. The dog and
  the panel are in it. It is saved as "recording HH-MM-SS.mp4" in the session
  folder; the phone says when it is saved. "MapleSyrup (recording and
  streaming)" from the Start menu records from the start.
  The first time, MapleSyrup downloads ffmpeg (about 150 MB, kept in
  %APPDATA%\MapleSyrup\ffmpeg) to do the recording; it uses the graphics
  card's video encoder when there is one. Each sound is put where it was
  heard, so the voices match the picture. If MapleSyrup is closed while
  recording, it finishes the file first; if it can't, the "(unfinished)" file
  still plays.
  To check recording on a PC: MapleSyrup.exe --record-test (a few seconds of
  the screen with a flash and a tone, which must line up).

Streaming it
  Start "MapleSyrup (recording and streaming)" from the Start menu (in the zip:
  double-click "MapleSyrup (recording).cmd"): the dog and the panel then show
  up in OBS (normally they keep out of captures, except while MapleSyrup
  records), and what the phone's microphone hears is kept as mic.wav in the
  session folder. In OBS use "Display Capture" ("Game Capture" sees only the
  game window).

If the phone cannot connect
  Start "MapleSyrup" or "MapleSyrup without Claude" from the Start menu (in
  the zip: double-click "MapleSyrup with Claude.cmd" or "MapleSyrup (phone
  over internet).cmd"). They link the phone through a Cloudflare tunnel: no
  certificate warning, no firewall question, works on mobile data too. The
  address changes each time: scan the QR code again.

If Windows blocks MapleSyrup.exe ("Smart App Control" / "blocked by your
organization's Device Guard policy")
  The program is not signed, and each new version is a file Windows has not
  seen before. Smart App Control cannot allow a single program:
  Windows Security -> App & browser control -> Smart App Control settings -> Off.
  (Since the April 2026 update it can be turned on again from the same place;
  MapleSyrup is then blocked again.)

Updates
  MapleSyrup updates itself. Now and then it looks at datta-syrup.ai for a
  new version, fetches it in the background and installs it the next time
  you start MapleSyrup (or right away: Settings on the phone -> Update now).
  It only takes a version signed by the release key built into it, and keeps
  the version you had beside it until the new one has run for a while; a
  version that does not come up twice is rolled back, and the one after it
  is tried instead. Turn it off in Settings on the phone, or start MapleSyrup
  with --no-update.

Workshop (off unless you turn it on)
  MapleSyrup can rewrite itself, on this PC only. Turn the workshop on in
  Details on the phone, then say "change yourself: make the HP warning
  shorter" (or type it there). A coding agent installed on this PC — Claude
  Code or Codex CLI, whichever you have — changes the source in the
  checkout at %USERPROFILE%\GitHub\ms (or where --repo says), the program is
  built and its tests run (a few minutes; the game keeps priority), and the
  new version installs the next time MapleSyrup starts, with the old one
  kept to go back to. "Undo the last change" takes it back. The work stays
  on a branch of this PC's own: nothing is pushed, nothing is published, and
  the site's updates are paused while the workshop is on. It needs git, the
  Rust toolchain and a coding agent on this PC; the first build fetches the
  dependencies and takes longer.

Claude, live (talk with Claude while it sees the game)
  Talk with Claude in the Claude app as usual, and Claude sees your game:
  MapleSyrup works in the background (no window, no voice of its own) and
  gives Claude what it knows - the screen as it is now (HP/MP/EXP with how
  old each number is, level, map, what moves on the screen and where, a
  dialog and its text, the things you taught it), a look at the screen,
  its own MapleStory wiki (Claude adds the facts it checked), and what it
  knows about you (your about-me.txt, which Claude can add to).
  Once: "Add MapleSyrup to the Claude app" in the Start menu (from the zip,
  double-click "Add MapleSyrup to Claude.cmd"; or run
  MapleSyrup.exe --install-claude), then quit the Claude app completely (its
  icon by the clock -> Quit) and open it again. From then on, in any chat,
  Claude uses the MapleSyrup that runs, or starts one in the background
  itself (it stops a few minutes after Claude's last question). The app
  runs a copy of MapleSyrup of its own (in %LOCALAPPDATA%\MapleSyrup), so
  MapleSyrup.exe itself is never held open by it. It needs the Claude
  desktop app on this PC.
  Claude Code too, with the game pushed to it as it happens (a death, a
  level-up, a new map, HP in danger) and MapleSyrup's voice to talk through
  from the phone: "MapleSyrup" on the desktop or in the Start menu (from the
  zip, double-click "MapleSyrup with Claude.cmd"), with the phone over the
  internet. It writes the Claude folder beside MapleSyrup.exe and starts
  Claude there; when Claude Code isn't on the PC (the installer puts it in)
  it installs it from claude.ai (about a minute), and Claude Code asks you
  to log in with your Claude account. (By hand: MapleSyrup.exe
  --setup-claude, then "Start Claude.cmd" in the Claude folder, which hands
  what it is given to MapleSyrup: "Start Claude.cmd" --tunnel.) That
  session is Claude for anything, as in the Claude app - talk about
  anything, search the web, read and open your files (Desktop, Documents,
  Downloads, Pictures...), build projects (in Documents\Claude projects) -
  and it is in the Claude app too (Remote Control). It runs in Claude Code's
  auto mode: instead of asking you about each action, Claude has each one
  checked first. Claude Code asks each time whether to load a "development
  channel" - choose "I am using this for local development". Each start
  sets the folder up again; a MapleSyrup-new.exe left beside MapleSyrup.exe
  is put in its place first.
  Started this way, MapleSyrup leaves all the talking to Claude: none of its
  own answers, live calls or remarks, and while Claude isn't connected (its
  window waits for an answer, say), it tells you so instead. Both can run at
  once - the live session and Claude in the Claude app's chats: they use
  the same MapleSyrup (the one with a window takes over from one the app
  started in the background).
  Claude can save a picture of the game (save_picture, into Documents\Claude
  projects\MapleSyrup pictures) to work with, and show you your character
  in other items (drawn by maplestory.io).

Privacy
  Your keys stay on this PC (%APPDATA%\MapleSyrup); a live call uses a key
  that works for a few minutes only, made for it.
  With an OpenAI key, to answer you, OpenAI gets: what you say (on a live
  call, your voice itself), the conversation, what it reads off the game
  (level, bars, map), pictures of your game window - only while MapleStory
  is the window in front - and its notebook about you (memory.json,
  about-me.txt and the lessons in knowledge.json), with each reply and with
  each look the coach takes (about every minute or three while you play).
  Every few minutes it also sends the notebook and the latest conversation
  (not the pictures) to update the notebook, which is kept on your PC. While
  it learns to read your HUD, it sends a picture of the game window and
  crops of the HUD.
  With an xAI key, the regular replies go to xAI (Grok) with the same: what
  you say, a small picture of the game and the notebook. With an ElevenLabs
  key, what it says goes to ElevenLabs to be spoken.
  Outside a live call, your phone's browser turns your speech into text with
  its own speech service (Google's on Chrome and Android, Apple's on
  Safari): your voice goes there, with or without any key. With "phone over
  the internet", everything the phone and the PC exchange goes through
  Cloudflare.
  Updates: it asks datta-syrup.ai for a new version 45 s after it starts and
  then hourly (a plain request: your IP address, and that MapleSyrup runs);
  off with --no-update or on the phone.
  The workshop (off unless you turn it on) hands your request and the end of
  the session's log to the coding agent on your PC, which sends them to its
  own provider (Anthropic or OpenAI).
  Claude, live (only once you add MapleSyrup to Claude): Claude gets what
  MapleSyrup reads off the game, its wiki, your about-me.txt and notebook,
  and - when Claude asks to look - pictures of the game window, and sends
  them to Anthropic as part of your Claude conversation. MapleSyrup serves
  them on this PC only (127.0.0.1, with a key), never through the tunnel.
  In the Claude Code session, the files Claude reads for you (your folders
  are open to it without asking) and its web searches are part of your
  Claude conversation too, as in the Claude app.
  "The game" is any window whose title contains "MapleStory".
  OpenAI bills your account: a live call costs more than the PC voice (very
  roughly a dollar or two per hour of play, depending on how much you talk).
  Without a key and with updates off, nothing leaves your PC except the
  phone link on your own network (and the phone's own speech recognition).
  Recordings are made and kept on your PC only, and only when you ask for one;
  a recording holds the whole screen and every sound of the PC.
  Play stats: MapleSyrup keeps numbers about each session on this PC (minutes,
  levels, deaths, warnings, how fast it answered; in %APPDATA%\MapleSyrup\metrics)
  and never your character's name, what you say, your voice, pictures or your
  files. Sharing them with anyone is not offered: it first needs a rights
  review for MapleStory and consent asked for each purpose. Nothing is sent
  anywhere.

Files
  Each session is kept in "MapleSyrup sessions" (in Documents when installed,
  next to MapleSyrup.exe from the zip):
  log.txt (what was said and heard), markers.csv and mark-NNN.png, the
  recordings (recording HH-MM-SS.mp4), and mic.wav when started with
  --record-mic.
  Optional: write a few lines about yourself in %APPDATA%\MapleSyrup\about-me.txt
  (your name, your class, what you're working towards) and it will know them.

More options: open a terminal here and run  MapleSyrup.exe --help
vision_debug.exe is the engine's own debugger (what it sees, frame by frame).
